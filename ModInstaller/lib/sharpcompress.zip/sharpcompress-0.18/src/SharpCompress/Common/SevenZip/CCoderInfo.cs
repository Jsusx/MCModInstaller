﻿namespace SharpCompress.Common.SevenZip
{
    internal class CCoderInfo
    {
        internal CMethodId MethodId;
        internal byte[] Props;
        internal int NumInStreams;
        internal int NumOutStreams;
    }
}
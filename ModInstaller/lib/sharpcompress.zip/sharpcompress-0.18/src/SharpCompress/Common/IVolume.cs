﻿using System;

#if !NO_FILE
using System.IO;
#endif

namespace SharpCompress.Common
{
    public interface IVolume : IDisposable
    {
    }
}
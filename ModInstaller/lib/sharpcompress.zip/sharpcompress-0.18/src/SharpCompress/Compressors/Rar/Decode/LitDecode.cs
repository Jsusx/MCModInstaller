namespace SharpCompress.Compressors.Rar.Decode
{
    internal class LitDecode : Decode
    {
        internal LitDecode()
            : base(new int[Compress.NC])
        {
        }
    }
}
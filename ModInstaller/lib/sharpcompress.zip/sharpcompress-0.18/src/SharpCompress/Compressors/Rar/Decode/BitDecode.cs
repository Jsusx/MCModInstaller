namespace SharpCompress.Compressors.Rar.Decode
{
    internal class BitDecode : Decode
    {
        internal BitDecode()
            : base(new int[Compress.BC])
        {
        }
    }
}
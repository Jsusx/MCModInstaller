namespace SharpCompress.Compressors.Rar.Decode
{
    internal class RepDecode : Decode
    {
        internal RepDecode()
            : base(new int[Compress.RC])
        {
        }
    }
}